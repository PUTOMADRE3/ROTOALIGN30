package com.rotoalign30.app

import android.app.Activity
import android.app.AlertDialog
import android.os.Bundle
import android.text.InputType
import android.graphics.Color
import android.view.Gravity
import android.view.View
import android.widget.*

class MainActivity : Activity() {
    private val bg = Color.rgb(15, 23, 34)
    private val panel = Color.rgb(27, 39, 55)
    private val blue = Color.rgb(35, 137, 255)
    private val white = Color.WHITE
    private val muted = Color.rgb(174, 188, 205)
    private val supportValues = mutableListOf<SupportPoint>()

    data class SupportPoint(
        val number: Int,
        var x: String = "",
        var y: String = "",
        var measuredHeight: String = "",
        var targetHeight: String = ""
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showHome()
    }

    private fun baseLayout(): LinearLayout {
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(20, 22, 20, 20)
            setBackgroundColor(bg)
        }
    }

    private fun label(text: String, size: Float = 16f, color: Int = white): TextView =
        TextView(this).apply {
            this.text = text
            textSize = size
            setTextColor(color)
            setPadding(0, 8, 0, 8)
        }

    private fun actionButton(text: String, onClick: () -> Unit): Button =
        Button(this).apply {
            this.text = text
            setTextColor(white)
            setBackgroundColor(blue)
            setOnClickListener { onClick() }
        }

    private fun card(title: String, subtitle: String, onClick: () -> Unit): LinearLayout {
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(18, 12, 18, 12)
            setBackgroundColor(panel)
            addView(label(title, 18f))
            addView(label(subtitle, 13f, muted))
            setOnClickListener { onClick() }
            val params = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
            params.setMargins(0, 8, 0, 8)
            layoutParams = params
        }
    }

    private fun showHome() {
        val root = baseLayout()
        root.addView(label("ROTOALIGN 30", 28f, blue))
        root.addView(label("ALINEACIÓN INDUSTRIAL · MOTOR Y BOMBA", 12f, muted))
        root.addView(label("Herramientas de trabajo", 20f))
        root.addView(card("01  Nuevo proyecto", "Identificación del equipo y trabajo") {
            showProjectDialog()
        })
        root.addView(card("02  Rim & Face", "Captura de lecturas de reloj comparador") {
            showRimFace()
        })
        root.addView(card("03  Puntos de apoyo", "Configura y registra de 1 a 30 apoyos") {
            showSupportsSetup()
        })
        root.addView(card("04  Historial", "Preparado para incorporar proyectos guardados") {
            info("Historial", "El almacenamiento de proyectos se incorporará en la siguiente etapa.")
        })
        root.addView(card("05  Reportes", "Preparado para generar informes PDF") {
            info("Reportes", "La exportación PDF se incorporará después de validar los cálculos.")
        })
        setContentView(root)
    }

    private fun showProjectDialog() {
        val name = EditText(this).apply { hint = "Nombre del equipo (ej. Bomba P-101)" }
        val motor = EditText(this).apply { hint = "Motor / potencia / RPM" }
        val pump = EditText(this).apply { hint = "Bomba / modelo" }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 8, 24, 0)
            addView(name); addView(motor); addView(pump)
        }
        AlertDialog.Builder(this)
            .setTitle("Nuevo proyecto")
            .setView(box)
            .setPositiveButton("Guardar") { _, _ ->
                info("Proyecto capturado", "Equipo: ${name.text}\nMotor: ${motor.text}\nBomba: ${pump.text}\n\nEn esta versión inicial los datos son temporales.")
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun showSupportsSetup() {
        val input = EditText(this).apply {
            hint = "Cantidad de apoyos (1 a 30)"
            inputType = InputType.TYPE_CLASS_NUMBER
            setText(if (supportValues.isEmpty()) "4" else supportValues.size.toString())
        }
        AlertDialog.Builder(this)
            .setTitle("Configurar apoyos físicos")
            .setMessage("Indica cuántos puntos de apoyo tiene la base.")
            .setView(input)
            .setPositiveButton("Crear") { _, _ ->
                val count = input.text.toString().toIntOrNull()
                if (count == null || count !in 1..30) {
                    info("Cantidad no válida", "Introduce un número entero entre 1 y 30.")
                } else {
                    supportValues.clear()
                    repeat(count) { supportValues.add(SupportPoint(it + 1)) }
                    showSupportEditor()
                }
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun showSupportEditor() {
        val scroll = ScrollView(this)
        val root = baseLayout()
        root.addView(label("PUNTOS DE APOYO", 24f, blue))
        root.addView(label("${supportValues.size} apoyos configurados", 14f, muted))
        root.addView(label("Registra coordenadas y alturas en mm. Usa el mismo plano de referencia para todos los puntos.", 13f, muted))
        supportValues.forEachIndexed { index, point ->
            val block = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(14, 10, 14, 10)
                setBackgroundColor(panel)
            }
            block.addView(label("PUNTO ${point.number}", 17f, blue))
            val x = field("Posición X (mm)", point.x)
            val y = field("Posición Y (mm)", point.y)
            val measured = field("Altura medida (mm)", point.measuredHeight, true)
            val target = field("Altura objetivo (mm)", point.targetHeight, true)
            block.addView(x); block.addView(y); block.addView(measured); block.addView(target)
            val p = LinearLayout.LayoutParams(-1, -2)
            p.setMargins(0, 8, 0, 8)
            root.addView(block, p)
            pointInputs.add(PointInputs(point, x, y, measured, target))
        }
        root.addView(actionButton("Guardar mediciones") {
            pointInputs.forEach { entry ->
                entry.point.x = entry.x.text.toString()
                entry.point.y = entry.y.text.toString()
                entry.point.measuredHeight = entry.measured.text.toString()
                entry.point.targetHeight = entry.target.text.toString()
            }
            val incomplete = supportValues.count {
                it.measuredHeight.isBlank() || it.targetHeight.isBlank()
            }
            info("Registro revisado", "Puntos configurados: ${supportValues.size}\nLecturas de altura pendientes: $incomplete\n\nLa diferencia de altura se habilitará cuando se implemente la validación del plano de referencia.")
        })
        root.addView(actionButton("Volver al inicio") { showHome() })
        scroll.addView(root)
        pointInputs.clear()
        setContentView(scroll)
    }

    private data class PointInputs(
        val point: SupportPoint,
        val x: EditText,
        val y: EditText,
        val measured: EditText,
        val target: EditText
    )
    private val pointInputs = mutableListOf<PointInputs>()

    private fun field(hintText: String, value: String = "", decimal: Boolean = false): EditText =
        EditText(this).apply {
            hint = hintText
            setText(value)
            setTextColor(white)
            setHintTextColor(muted)
            inputType = if (decimal)
                InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL or InputType.TYPE_NUMBER_FLAG_SIGNED
            else
                InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL or InputType.TYPE_NUMBER_FLAG_SIGNED
        }

    private fun showRimFace() {
        val scroll = ScrollView(this)
        val root = baseLayout()
        root.addView(label("RIM & FACE", 25f, blue))
        root.addView(label("Captura de lecturas del reloj comparador. Convención inicial: 0° arriba, 90° derecha, 180° abajo y 270° izquierda.", 13f, muted))
        root.addView(label("LECTURAS RIM · RADIAL", 17f))
        val rim0 = field("Rim 0° (mm)")
        val rim90 = field("Rim 90° (mm)")
        val rim180 = field("Rim 180° (mm)")
        val rim270 = field("Rim 270° (mm)")
        root.addView(rim0); root.addView(rim90); root.addView(rim180); root.addView(rim270)
        root.addView(label("LECTURAS FACE · AXIAL", 17f))
        val face0 = field("Face 0° (mm)")
        val face90 = field("Face 90° (mm)")
        val face180 = field("Face 180° (mm)")
        val face270 = field("Face 270° (mm)")
        root.addView(face0); root.addView(face90); root.addView(face180); root.addView(face270)
        val diameter = field("Diámetro efectivo de lectura Face (mm)")
        root.addView(diameter)
        root.addView(label("No se calcularán correcciones hasta confirmar sentido de contacto, signo, montaje y compensación de caída del soporte.", 12f, muted))
        root.addView(actionButton("Validar captura") {
            val fields = listOf(rim0,rim90,rim180,rim270,face0,face90,face180,face270,diameter)
            val missing = fields.count { it.text.toString().trim().isEmpty() }
            val d = diameter.text.toString().toDoubleOrNull()
            if (missing > 0 || d == null || d <= 0.0) {
                info("Faltan datos", "Completa las ocho lecturas y un diámetro Face mayor que cero.")
            } else {
                info("Captura completa", "Las lecturas están registradas en pantalla. Falta confirmar la convención de signos y validar el montaje antes de habilitar resultados.")
            }
        })
        root.addView(actionButton("Volver al inicio") { showHome() })
        scroll.addView(root)
        setContentView(scroll)
    }

    private fun info(title: String, message: String) {
        AlertDialog.Builder(this).setTitle(title).setMessage(message)
            .setPositiveButton("Aceptar", null).show()
    }
}
