ROTOALIGN 30 - Proyecto Android inicial

Contenido:
- Proyecto Android nativo en Kotlin.
- Pantalla principal.
- Captura inicial de proyecto.
- Configuración de 1 a 30 apoyos físicos.
- Formulario de coordenadas y alturas.
- Formulario de lecturas Rim & Face con validación de campos.

Importante:
Esta es una base de interfaz y captura, no una herramienta validada para emitir correcciones de alineación.
Los cálculos de Rim & Face requieren confirmar la convención de signos, el sentido de contacto del reloj,
la geometría del montaje, el método de lectura y la compensación de caída del soporte.
Las mediciones de apoyo requieren definir plano de referencia, condición de carga y criterio de nivelación.

Abrir:
1. Descomprime el ZIP.
2. Abre la carpeta ROTOALIGN30_Android desde AndroidIDE.
3. Permite la sincronización de Gradle y descarga de dependencias si AndroidIDE las solicita.
4. Ejecuta la app en tu dispositivo.

Configuración:
- Android Gradle Plugin 8.6.1
- Kotlin 2.0.21
- compileSdk 35
- minSdk 23
